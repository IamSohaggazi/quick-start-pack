/*
* ----------------------------------------------------------------------------------------
Author       : CodeMate
Template Name: Arizona Digital Agency OnePage Tempalte.
Version      : 1.0
* ----------------------------------------------------------------------------------------
*/

(function ($) {
    'use strict';

    jQuery(document).ready(function () {
    
	   /*Start Preloder*/
		$(window).on('load', function() {
            $('.preloader').fadeOut();
            $('.preloader-area').delay(350).fadeOut('slow');
        });
       /*End Preloder*/
		
	 /*Start Testimonail*/ 
        $(".testimonial-list").owlCarousel({
            items: 2,
            autoPlay: true,
            navigation: false,
            itemsDesktop: [1199, 2],
            itemsDesktopSmall: [980, 2],
            itemsTablet: [768, 1],
            itemsTabletSmall: false,
            itemsMobile: [479, 1],
            autoHeight: true,
            pagination: true,
        }); 
	   /*End Testimonail*/

	 /*Start Team Js*/ 
        $(".team-list").owlCarousel({
            items: 3,
            autoPlay: true,
            navigation: false,
            itemsDesktop: [1199, 1],
            itemsDesktopSmall: [980, 2],
            itemsTablet: [768, 2],
            itemsTabletSmall: false,
            itemsMobile: [479, 1],
            autoHeight: true,
            pagination: true,
        });
	   /*End Team Js*/
	   
	    /*Start Mixitup*/
        $('.portfolio-items-inner').mixItUp();
        /*End Mixitup*/
		
		/*Start Video*/
		$('.play-video').magnificPopup({
            type: 'iframe'
        });
		/*End Video*/
		
		/*Start Manu Chage Bg*/
		$(window).on('scroll', function () {
            if ($(window).scrollTop() > 200) {
                $('.header-top-area').addClass('fixed-menu-bg');
            } else {
                $('.header-top-area').removeClass('fixed-menu-bg');
            }
        });
		/*End Manu Chage Bg*/
		
		/*Start Perallax*/
        $(window).stellar({
            responsive: true,
            positionProperty: 'position',
            horizontalScrolling: false
        });
		/*End Perallax*/
		
		/*Start Counter Up*/
		$('.counter-number').counterUp({
			time: 2000,
			delay: 10
		});
		/*End Counter Up*/

		
	    /*Start Comming Soon*/
		var launchDay = new Date(2019, 12-1, 8);
		  $('#timer').countdown({
		  until: launchDay
		});
       /*End Comming Soon*/
	   
		/*Start Bootstrap Scroll-Spy*/
	    $('body').scrollspy({
        target: '.navbar-collapse',
        offset: 195
        });
		/*End Bootstrap Scroll-Spy*/
		
		/*Start Magnifix Popup*/
		 var magnifPopup = function () {
            $('.portfolio-popup').magnificPopup({
                type: 'image',
                removalDelay: 300,
                mainClass: 'mfp-with-zoom',
                gallery: {
                    enabled: true
                },
                zoom: {
                    enabled: true, // By default it's false, so don't forget to enable it

                    duration: 300, // duration of the effect, in milliseconds
                    easing: 'ease-in-out', // CSS transition easing function

                    // The "opener" function should return the element from which popup will be zoomed in
                    // and to which popup will be scaled down
                    // By defailt it looks for an image tag:
                    opener: function (openerElement) {
                        // openerElement is the element on which popup was initialized, in this case its <a> tag
                        // you don't need to add "opener" option if this code matches your needs, it's defailt one.
                        return openerElement.is('img') ? openerElement : openerElement.find('img');
                    }
                }
            });
        };
        // Call the functions 
        magnifPopup();
	   /*End Magnifix Popup*/
		
        /*Start Smooth Scroll*/
		$('a.smooth-scroll').on("click", function (e) {
            var anchor = $(this);
            $('html, body').stop().animate({
                scrollTop: $(anchor.attr('href')).offset().top - 50
            }, 1000);
            e.preventDefault();
        });
        /*End Smooth Scroll*/		
		
		/*Start Scrool To Top*/
		$(window).scroll(function () {
            if ($(this).scrollTop() > 250) {
                $('.scrollup').fadeIn();
            } else {
                $('.scrollup').fadeOut();
            }
        });
        $('.scrollup').on("click", function () {
            $("html, body").animate({
                scrollTop: 0
            }, 800);
            return false;
        });
		/*End Scrool To Top*/
	
		/*Start Map*/
        var contact = {
            "lat": "38.907192",
            "lon": "-77.036871"
        }; //Change a map coordinate here!
        try {
            $('.map').gmap3({
                action: 'addMarker',
                latLng: [contact.lat, contact.lon],
                map: {
                    center: [contact.lat, contact.lon],
                    zoom: 6,
				    styles:
					[
						{
							"featureType": "landscape",
							"stylers": [
								{
									"hue": "#FFBB00"
								},
								{
									"saturation": 43.400000000000006
								},
								{
									"lightness": 37.599999999999994
								},
								{
									"gamma": 1
								}
							]
						},
						{
							"featureType": "road.highway",
							"stylers": [
								{
									"hue": "#FFC200"
								},
								{
									"saturation": -61.8
								},
								{
									"lightness": 45.599999999999994
								},
								{
									"gamma": 1
								}
							]
						},
						{
							"featureType": "road.arterial",
							"stylers": [
								{
									"hue": "#FF0300"
								},
								{
									"saturation": -100
								},
								{
									"lightness": 51.19999999999999
								},
								{
									"gamma": 1
								}
							]
						},
						{
							"featureType": "road.local",
							"stylers": [
								{
									"hue": "#FF0300"
								},
								{
									"saturation": -100
								},
								{
									"lightness": 52
								},
								{
									"gamma": 1
								}
							]
						},
						{
							"featureType": "water",
							"stylers": [
								{
									"hue": "#0078FF"
								},
								{
									"saturation": -13.200000000000003
								},
								{
									"lightness": 2.4000000000000057
								},
								{
									"gamma": 1
								}
							]
						},
						{
							"featureType": "poi",
							"stylers": [
								{
									"hue": "#00FF6A"
								},
								{
									"saturation": -1.0989010989011234
								},
								{
									"lightness": 11.200000000000017
								},
								{
									"gamma": 1
								}
							]
						}
					]

                },
            }, {
                action: 'setOptions',
                args: [{
                    scrollwheel: false
                }]
            });
        } catch (err) {}
        /*End Map*/
		
       /*Start Type Effect Js*/
        var TxtType = function (el, toRotate, period) {
            this.toRotate = toRotate;
            this.el = el;
            this.loopNum = 0;
            this.period = parseInt(period, 10) || 1000;
            this.txt = '';
            this.tick();
            this.isDeleting = false;
        };

        TxtType.prototype.tick = function () {
            var i = this.loopNum % this.toRotate.length;
            var fullTxt = this.toRotate[i];

            if (this.isDeleting) {
                this.txt = fullTxt.substring(0, this.txt.length - 1);
            } else {
                this.txt = fullTxt.substring(0, this.txt.length + 1);
            }

            this.el.innerHTML = '<span class="wrap">' + this.txt + '</span>';

            var that = this;
            var delta = 150 - Math.random() * 100;

            if (this.isDeleting) {
                delta /= 2;
            }

            if (!this.isDeleting && this.txt === fullTxt) {
                delta = this.period;
                this.isDeleting = true;
            } else if (this.isDeleting && this.txt === '') {
                this.isDeleting = false;
                this.loopNum++;
                delta = 500;
            }

            setTimeout(function () {
                that.tick();
            }, delta);
        };

        window.onload = function () {
            var elements = document.getElementsByClassName('typewrite');
            for (var i = 0; i < elements.length; i++) {
                var toRotate = elements[i].getAttribute('data-type');
                var period = elements[i].getAttribute('data-period');
                if (toRotate) {
                    new TxtType(elements[i], JSON.parse(toRotate), period);
                }
            }
            // INJECT CSS
            var css = document.createElement("style");
            css.type = "text/css";
            css.innerHTML = ".typewrite > .wrap { border-right: 0.02em solid #fff}";
            document.body.appendChild(css);
        };		
		/*End Type Effect Js*/	
		
    });

})(jQuery);