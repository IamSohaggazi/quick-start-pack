/*
* ----------------------------------------------------------------------------------------
Author       : themepoke
Template Name: unknown Personal Portfolio Template
Version      : 1.0
* ----------------------------------------------------------------------------------------
*/

(function ($) {
    'use strict';

    jQuery(document).ready(function () {

       
    });

})(jQuery);